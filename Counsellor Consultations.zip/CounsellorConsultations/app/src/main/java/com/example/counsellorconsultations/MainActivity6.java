package com.example.counsellorconsultations;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.trusted.sharing.ShareTarget;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity6 extends AppCompatActivity {

    private EditText Notestext;
    private EditText Name1text;
    private Button back;
    private Button submit2;
    ProgressDialog progressDialog;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        back = findViewById(R.id.back);
        submit2 = findViewById(R.id.submit2);
        Notestext = findViewById(R.id.Notestext);
        Name1text = findViewById(R.id.Name1text);

        progressDialog = new ProgressDialog(MainActivity6.this);
        progressDialog.setMessage("Loading...");


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity6.this, MainActivity2.class);
                startActivity(i);
            }
        });

        submit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addStudentData();
                progressDialog.show();

            }
        });



    }

    private void addStudentData() {
        String sName = Name1text.getText().toString();
        String sNotes = Notestext.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbx34a_kbVCOhNkabeI9Oh2gqVFET-z3WLRWWRRO_nfoQsSqC_hGJ-58J1Z9Majsk68/exec", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent intent = new Intent(getApplicationContext(),MainActivity6.class);
                startActivity(intent);
                progressDialog.hide();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }

        }){
            @Nullable
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                params.put("action", "addStudent");
                params.put("vName", sName);
                params.put("vNotes", sNotes);

                return params;

            }
        };
        int socketTimeOut = 50000;
        RetryPolicy retryPolicy= new DefaultRetryPolicy(socketTimeOut,0,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        Intent i = new Intent(MainActivity6.this, MainActivity2.class);
        startActivity(i);


    }


}


