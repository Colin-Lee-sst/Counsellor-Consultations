package com.example.counsellorconsultations;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity4 extends AppCompatActivity {

    private EditText etname, etclass1, ettime, etemail, etnumber, etothers, etdate;
    private Button submit;
    private Button back2;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        etname = findViewById(R.id.etname);
        etclass1 = findViewById(R.id.etclass1);
        ettime = findViewById(R.id.ettime);
        etemail = findViewById(R.id.etemail);
        etnumber = findViewById(R.id.etnumber);
        etothers = findViewById(R.id.etothers);
        etdate = findViewById(R.id.etdate);
        submit = findViewById(R.id.submit);
        back2 = findViewById(R.id.back2);

        progressDialog = new ProgressDialog(MainActivity4.this);
        progressDialog.setMessage("Loading...");


        back2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity4.this, MainActivity2.class);
                startActivity(i);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addStudentdata2();
                progressDialog.show();
            }
        });
    }

    private void addStudentdata2() {

        String sName2 = etname.getText().toString();
        String sClass2 = etclass1.getText().toString();
        String sEmail2 = etemail.getText().toString();
        String sOthers2 = etothers.getText().toString();
        String sTime2 = ettime.getText().toString();
        String sDate2 = etdate.getText().toString();
        String sNumber2 = etnumber.getText().toString();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbyLUzT4mzz-NvXYzbtSxLU3iyS3q3cRcd0ZmjDkdnZB6I7lOYsMSZqo1OkLQyfZn7KIvQ/exec", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent intent = new Intent(getApplicationContext(), MainActivity4.class);
                startActivity(intent);
                progressDialog.hide();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                params.put("action", "addStudent2");
                params.put("vName", sName2);
                params.put("vClass", sClass2);
                params.put("vEmail", sEmail2);
                params.put("vOthers", sOthers2);
                params.put("vNumber", sNumber2);
                params.put("vTime", sTime2);
                params.put("vDate",sDate2);

                return params;
            }
        };

        int socketTimeOut = 50000;
        RetryPolicy retryPolicy= new DefaultRetryPolicy(socketTimeOut,0,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        Intent intent = new Intent(MainActivity4.this, MainActivity2.class);
        intent.putExtra("Date", sDate2);
        intent.putExtra("Time", sTime2);
        startActivity(intent);

    }
}




  