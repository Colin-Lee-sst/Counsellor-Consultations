package com.example.counsellorconsultations;

public class Mood {
    private String Name;
    private String Mood;

    public Mood() {}
    public String getName(){
        return Name;
    }

    public void setName (String name) {Name = name;}
    public String getMood () {return Mood;}
    public void setMood (String mood) {Mood = mood;}

}
