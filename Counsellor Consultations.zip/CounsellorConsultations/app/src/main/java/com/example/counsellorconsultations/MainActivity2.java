package com.example.counsellorconsultations;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity2 extends AppCompatActivity {
    private Button Logout;
    private Button Add;
    private TextView ViewConsultations;
    private Button NotesButton;
    private TextView DateConsult;
    private TextView TimeConsult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        DateConsult = findViewById(R.id.DateConsult);
        TimeConsult = findViewById(R.id.TimeConsult);

        String Date = getIntent().getStringExtra("Date");
        String Time = getIntent().getStringExtra("Time");

        DateConsult.setText(Date);
        TimeConsult.setText(Time);






       NotesButton = findViewById(R.id.NoteButton);
       NotesButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent i = new Intent(MainActivity2.this, MainActivity6.class);
               startActivity(i);
           }
       });


               Logout = findViewById(R.id.Logout);

        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent i = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(i);

            }
        });


        Add = findViewById(R.id.add2);
        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this, MainActivity4.class);
                startActivity(i);
            }
        });









    }
}