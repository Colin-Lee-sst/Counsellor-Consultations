package com.example.counsellorconsultations;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity3 extends AppCompatActivity {
    private Button next_buttons;
    private RadioButton awesome_button;
    private RadioButton terrible_button;
    private RadioButton Unsure_button;
    private FirebaseDatabase Database;
    private DatabaseReference reference;
    int i = 0;
    private EditText name_textfield;
    Mood mood;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        awesome_button = findViewById(R.id.Awesome_button);
        mood = new Mood();
        next_buttons = findViewById(R.id.next_button);
        Unsure_button = findViewById(R.id.Unsure_button);
        terrible_button = findViewById(R.id.terrible_button);
        name_textfield = findViewById(R.id.name_textfield);
        reference = Database.getInstance().getReference().child("User");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                 if (snapshot.exists()) {
                     i = (int)snapshot.getChildrenCount();
                 }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                ////
            }
        });

        next_buttons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String m1 = awesome_button.getText().toString();
                String m2 = Unsure_button.getText().toString();
                String m3 = terrible_button.getText().toString();

                mood.setName(name_textfield.getText().toString());
                reference.child(String.valueOf(i+1)).setValue(mood);
                if (awesome_button.isChecked()) {
                    mood.setMood(m1);
                    reference.child(String.valueOf(i+1)).setValue(mood);

                } else {
                    if (Unsure_button.isChecked()) {
                    mood.setMood(m2);
                    reference.child(String.valueOf(i+2)).setValue(mood);

                } else {
                        mood.setMood(m3);
                        reference.child(String.valueOf(i + 3)).setValue(mood);

                    }

                }

                Intent i = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(i);



            }})


    ;}}


